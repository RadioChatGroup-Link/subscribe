---
name: '功能请求'
about: '建议这个项目的想法'
title: ''
labels: 'Status: Review Needed'
assignees: ''

---

**确保你已经看过 readme，也搜索并阅读过和你遇到的情况相关的问题。否则会被认为是重复的并被立刻关闭。**

**功能描述**
简明扼要地描述需要的功能

**额外信息**