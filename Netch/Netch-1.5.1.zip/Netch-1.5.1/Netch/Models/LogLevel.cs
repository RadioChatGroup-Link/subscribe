namespace Netch.Models
{
    public enum LogLevel
    {
        INFO,
        WARNING,
        ERROR
    }
}