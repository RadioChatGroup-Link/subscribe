﻿namespace Netch.Override
{
    public class ToolStripProfessionalRender : System.Windows.Forms.ToolStripProfessionalRenderer
    {
        protected override void OnRenderToolStripBorder(System.Windows.Forms.ToolStripRenderEventArgs e)
        {
            // ignored   
        }
    }
}
